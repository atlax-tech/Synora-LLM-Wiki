# Synora Wiki 高保真原型

这是 `DESIGN.md` 的可运行视觉合同，不是正式产品技术栈。它使用 React/Vite 复原概念设计的 macOS 四栏界面，并让设计验收所需的核心交互真实可用。

## 运行

```bash
pnpm install
pnpm run dev
```

打开 `http://127.0.0.1:5173/`。

## 可验证交互

- 搜索记录并保持笔记/手帐筛选。
- 在笔记与手帐之间切换。
- 切换当前记录、新建记录、编辑标题和正文。
- 收起/展开全局侧边栏。
- 执行 AI 助手快捷动作或输入问题，查看模拟结果。
- 打开 AI Skills、启停 Skill 并触发安装入口。
- 导出当前 1280×720 高保真原型图。

原型的 AI 结果与数据均为本地模拟，目的是验证信息层级、状态和交互；正式能力按根目录 `TECHNICAL.md` 实现。

## 视觉资产

`public/assets/` 中的照片与地图由内置 ImageGen 按概念图的自然、安静、低饱和方向生成。功能图标使用 Phosphor Icons，正式 macOS 版本映射为 SF Symbols。

## QA

- 最终基准：`screenshots/Synora-Wiki-HiFi-Prototype-1280x720.png`
- 整体同屏对照：`screenshots/design-qa-comparison.png`
- 编辑器/检查器聚焦对照：`screenshots/design-qa-focused.png`
- `scripts/create_qa_composite.py` 可重新生成对照图。

