# Synora Wiki 开发计划

文档版本：1.0  
用途：在 `SPEC.md` 的阶段框架上拆分任务、依赖、开发准则、测试方法与验收标准。每个阶段启动时应由本文件继续派生更细的执行计划，但不得修改既定范围而不更新 PRD/SPEC。

## 1. 执行规则

### 1.1 完成定义（Definition of Done）

一个任务只有同时满足以下条件才可标记完成：

- 实现与验收用例同时合入，不留下不可用占位入口。
- 错误、空状态、离线、取消、权限拒绝和恢复路径已处理。
- 影响数据格式时包含向前迁移、回滚说明和旧 fixture 测试。
- 影响 UI 时包含三尺寸 snapshot、键盘和 VoiceOver 检查。
- 影响 AI/同步/Skill 时包含超时、重试、幂等、审计和故障注入。
- 文档、ADR、权限说明和 traceability matrix 同步更新。
- 没有引入密钥、用户正文或敏感提示词日志。

### 1.2 开发准则

1. **本地提交先行**：用户操作先成为本地原子事务；索引、AI 和同步只能后置。
2. **主线程只做 UI**：解析、缩略图、索引、模型、同步和 Skill 全部有可取消后台边界。
3. **协议隔离**：Feature 不直接依赖 GRDB、CloudKit、供应商 SDK、WASI 或 Keychain。
4. **稳定标识**：Record/Block/Asset/Operation 在创建时即获得稳定 ID。
5. **写入统一**：用户、AI、导入、同步都通过 Command → ChangeSet → Transaction 路径。
6. **AI 不可信**：自由文本不能直接写库；结构输出须验证引用、revision、权限和风险。
7. **原始内容不可变**：修正、合并、删除都通过版本、tombstone 和显式操作表达。
8. **可重建派生层**：FTS、向量、摘要、OCR、关系和知识页有版本且能重建。
9. **视觉合同**：不得自行“优化”`DESIGN.md` 的列宽、色彩、圆角和信息层级。
10. **小批次集成**：每个批次保持工程可构建、库可迁移、数据可恢复。

### 1.3 分支与评审

- 分支命名：`codex/p<阶段>-<短任务>` 或 `feature/p<阶段>-<短任务>`。
- 每个 PR 只承担一个可验证目标；数据迁移与视觉重构不在同一 PR 混做。
- PR 必填：关联需求 ID、风险、测试证据、数据迁移、UI 截图、隐私/权限变化、回滚办法。
- 领域/存储/同步/AI 安全模块至少两类证据：自动测试 + 设计/架构人工审查。

## 2. 全局测试方法

| 方法 | 何时运行 | 主要产物 |
|---|---|---|
| Unit/Property | 每次提交 | XCTest/Swift Testing 报告、随机种子 |
| Integration | 每个 PR、每日主干 | 临时库、迁移、作业、索引、Keychain fake |
| Contract | Provider/CloudKit/MCP 变更 | 录制 fixture、schema diff、live opt-in 结果 |
| Snapshot | UI 变更 | 三尺寸基线、差异图、颜色/布局阈值 |
| XCUITest | 每个 Feature 合入 | 核心路径视频/日志、失败截图 |
| Performance | 每日主干、阶段出口 | 启动/输入/搜索/导入/同步 trend |
| Recovery/Fault injection | 存储、AI、同步、Skill 变更 | kill/断网/磁盘满/重复事件报告 |
| Accessibility | 每阶段 | VoiceOver 脚本、键盘路径、对比度报告 |
| Security | P0 后持续，P6/P9 完整运行 | threat model、依赖/权限/日志扫描 |

## 3. P0 — 架构与风险探针

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P0-01 | 建立 Xcode workspace、targets、SwiftPM packages 和配置分层 | 无 | 可构建工程骨架 |
| P0-02 | 建立格式化、静态检查、单测、UI 测试与 CI | P0-01 | 质量门脚本与 CI 配置 |
| P0-03 | 定义 Domain entities、Repository/Clock/ID/Transaction 协议 | P0-01 | `SynoraDomain` v0 |
| P0-04 | TextKit 2 探针：IME、block ranges、attachment、undo、VoiceOver | P0-01 | 编辑器可行性报告 |
| P0-05 | GRDB WAL、operation log、snapshot/replay 探针 | P0-03 | 存储可行性报告 |
| P0-06 | CKSyncEngine 两设备/模拟器、离线和冲突探针 | P0-05 | 同步可行性报告 |
| P0-07 | XPC + WASI Skill 权限、崩溃、取消探针 | P0-01 | 隔离可行性报告 |
| P0-08 | 生成 10k records/100k blocks/20 GB media 基准库 | P0-03 | 固定 seed 测试数据 |
| P0-09 | 建立 threat model、数据分类和日志策略 | P0-03 | 安全文档 |
| P0-10 | 完成 ADR-001…006 并冻结主要技术路线 | P0-04…09 | 审批后的 ADR |

### 测试方法

- 使用中文/英文/emoji/组合字符/第三方输入法 fixture 验证 TextKit range。
- 对 operation 随机生成 100k 次 insert/move/update/delete，并重放比对最终哈希。
- 模拟 CloudKit 重复、乱序、延迟和部分失败；验证幂等与冲突保留。
- 让 Skill 进程崩溃、超时、请求未授权路径/域名；验证主应用与数据不受影响。

### 阶段验收

- 所有 ADR 都有“选择/备选/证据/后果/回滚点”。
- P0-04/06/07 没有未知的致命风险；若主方案失败，备选已实际跑通。
- CI 在干净机器完成 build+unit+lint，基准结果可重复。

## 4. P1 — 原生壳层与设计系统

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P1-01 | 生成 color/type/spacing/radius/motion 语义 token | P0-10 | `SynoraDesignSystem` |
| P1-02 | 实现四栏 WindowGroup、列宽约束、折叠和恢复 | P1-01 | 主窗口壳 |
| P1-03 | 实现顶部工具栏、状态栏、菜单和命令 | P1-02 | 原生 chrome |
| P1-04 | 实现侧栏分区、选中/悬停/计数和工具区 | P1-02 | LibraryNavigation |
| P1-05 | 实现搜索、笔记/手帐 selector、时间分组列表 | P1-02 | RecordList |
| P1-06 | 实现上下文与 AI Skills 检查器容器 | P1-02 | Inspector shell |
| P1-07 | 完成 loading/empty/error/offline/conflict 状态组件 | P1-04…06 | State catalog |
| P1-08 | 键盘焦点、VoiceOver、减少动态和高对比度 | P1-03…07 | Accessibility pass |
| P1-09 | 建立高保真三尺寸 snapshot 与像素比较 | P1-01…08 | Visual regression suite |
| P1-10 | XCUITest 覆盖主导航、列折叠、列表和检查器 | P1-02…08 | Shell UI tests |

### 测试方法

- 高保真原型与原生截图同屏比较；自动测 SSIM、关键几何和语义色。
- 调整窗口到最小/推荐/全屏、重启和多显示器移动，验证恢复。
- 仅键盘遍历；VoiceOver 读取层级与状态；减少动态开启后检查动画。

### 阶段验收

- 1280×720 主界面关键结构 SSIM ≥ 0.95；几何误差 ≤ 2 px。
- 1440×900 与 1728×1117 无拉伸、遮挡或错误空白。
- 没有不可达控件、焦点陷阱或需要鼠标的主路径。

## 5. P2 — 完整编辑与多媒体

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P2-01 | 定义 block schema、树不变量与 order key | P0-03 | Editor schema v1 |
| P2-02 | TextStorageAdapter 与 `SynoraTextView` | P0-04, P2-01 | 连续编辑核心 |
| P2-03 | 段落/标题/列表/任务/引用/代码/分隔线 | P2-02 | 基础 blocks |
| P2-04 | 表格/折叠/callout 与嵌套规则 | P2-03 | 高级 blocks |
| P2-05 | Markdown 快捷输入、斜杠菜单、@、[[ | P2-03 | 输入命令 |
| P2-06 | 选区格式栏、查找替换、拼写与复制粘贴 | P2-02 | 编辑工具 |
| P2-07 | Attachment staging、hash、缩略图与缓存 | P0-05 | Asset pipeline |
| P2-08 | 图片/拼贴/画廊、视频、音频、PDF、文件、链接 | P2-07, P2-03 | Media blocks |
| P2-09 | 自动保存、undo/redo、crash recovery、history | P0-05, P2-02 | 编辑持久性 |
| P2-10 | 手帐/笔记模板和元数据行 | P2-03, P1-05 | Journal editing |
| P2-11 | 单记录 Markdown/HTML/PDF/原始包往返 | P2-03…10 | Record exporter |
| P2-12 | 长文/媒体/IME/VoiceOver 性能与稳定性收敛 | 全部 | Editor quality gate |

### 测试方法

- 每种 block 做 create/edit/move/nest/copy/paste/export/import/undo/redo 参数化测试。
- 在 marked text 中进行换行、撤销、切换 block，确保不拆坏中文输入。
- 导入时注入磁盘满、重复文件、损坏媒体和进程终止。
- 100k 字+200 媒体连续输入、快速滚动和选择，记录 signpost。

### 阶段验收

- 所有 block 往返结构和 ID 保持；未知属性保留。
- 已确认输入在强退后零丢失；附件无孤立和错误引用。
- P95 输入 ≤ 16 ms；大文档首屏 ≤ 250 ms。
- 长文、多媒体、撤销和排版体验达到替代现有工具的标准。

## 6. P3 — 本地数据、检索与开放库

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P3-01 | 实现 schema v1、迁移 runner 与事务仓储 | P0-05 | SynoraStore |
| P3-02 | 实现 append-only Operation 与快照策略 | P3-01 | History engine |
| P3-03 | 实现 Job queue、lease、checkpoint、retry/cancel | P3-01 | Durable jobs |
| P3-04 | 内容寻址附件、去重、垃圾回收与容量诊断 | P2-07, P3-01 | Asset store |
| P3-05 | FTS5 schema、增量索引与结果高亮 | P3-01 | Local search |
| P3-06 | 中文 tokenizer 候选基准与选择 ADR | P3-05, P0-08 | Search ADR |
| P3-07 | 时间/类型/标签/来源/媒体组合筛选 | P3-05 | Filter engine |
| P3-08 | Synora 开放格式 materializer/parser | P3-01, P2-11 | Library format v1 |
| P3-09 | 全量/增量备份、校验、恢复和库健康工具 | P3-02, P3-04, P3-08 | Recovery tools |
| P3-10 | 删除/tombstone/保留期与回收站 | P3-01…04 | Deletion lifecycle |
| P3-11 | 10k/100k 数据集性能与故障注入 | 全部 | Storage/search report |

### 测试方法

- 每个 migration 从所有历史 fixture 升级并校验回滚/备份。
- operation property test：重复、乱序、并发和中断后最终状态一致。
- 备份中随机损坏文件，确保恢复前校验并报告具体问题。
- 搜索 goldens 覆盖中文、英文、混排、错别字、短语和过滤组合。

### 阶段验收

- 10k 记录 FTS P95 ≤ 150 ms；索引可全量重建且结果一致。
- 1,000 文件 ingest 的本地落库阶段中断恢复零重复。
- 备份在空白环境恢复全部记录、附件、历史和设置。
- 用户可读导出与运行态哈希核对通过。

## 7. P4 — LLM Wiki 引擎

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P4-01 | 实现 Raw/User/Wiki/Rules 数据边界与权限不变量 | P3-01 | Wiki domain |
| P4-02 | purpose/schema/policy/index/log 与版本管理 | P4-01 | RuleSet v1 |
| P4-03 | parser/chunker 插件接口与来源 provenance | P3-03, P4-01 | Normalize pipeline |
| P4-04 | 实体/事实/主题/摘要结构 schema | P4-02 | Extraction schemas |
| P4-05 | 候选页/关系召回与 Proposal 生成接口 | P4-04, P3-05 | Proposal builder |
| P4-06 | citation/revision/schema deterministic validator | P4-05 | Proposal validator |
| P4-07 | 风险策略与 ChangeSet 原子应用 | P3-02, P4-06 | Safe apply |
| P4-08 | embedding store、精确检索与模型版本重建 | P3-03, P3-05 | Semantic index |
| P4-09 | 混合 query、引用回答和命中解释 | P4-08, P4-06 | Query engine |
| P4-10 | typed relations 与图谱数据查询 API | P4-05, P4-07 | Relation layer |
| P4-11 | lint 检查、修复 Proposal 与 Inbox Review | P4-06…10 | Lint engine |
| P4-12 | schema migration dry-run/rollback/alias | P4-02, P4-07 | Rule migration |
| P4-13 | ingest/query/lint 固定语料 golden suite | 全部 | Wiki eval |

### 测试方法

- 固定原始语料与规则版本，对结构输出、引用、页面和关系做 golden diff。
- 对同一来源重复/中断 ingest，验证幂等键与 checkpoint。
- 人工插入矛盾、断链、无引用和 schema 违规，验证 lint 不误删。
- 全量删除派生层并重建，与基准哈希/语义指标比较。

### 阶段验收

- Raw/User 层从模型路径不可写；违规调用在编译边界和运行时双重失败。
- 派生知识 100% 有 provenance；无引用结论被明确标记。
- ingest/query/lint 的确定性部分可回归，模型部分达到预设评测阈值。
- 规则迁移能预览影响、取消和回滚。

## 8. P5 — AI Runtime、BYOK 与行内 AI

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P5-01 | `LanguageModelProvider`、请求/事件/capability 协议 | P4 schemas | AI core |
| P5-02 | Keychain profile、设置、连接测试和密钥删除 | P5-01 | BYOK settings |
| P5-03 | Apple/system/local OpenAI-compatible adapter | P5-01 | Local adapters |
| P5-04 | OpenAI/Anthropic/Gemini adapters | P5-01 | Cloud adapters |
| P5-05 | model discovery、capability matrix 与 contract fixtures | P5-03/04 | Provider contracts |
| P5-06 | task router、预算、隐私、健康状态和 fallback | P5-05 | Model routing |
| P5-07 | structured output decode 与 Proposal validator 集成 | P5-01, P4-06 | Safe AI output |
| P5-08 | diff/审批/provenance/撤销 UI | P5-07, P4-07 | Review UI |
| P5-09 | 行内 ghost text、stream、debounce、Tab/Esc/cancel | P2-02, P5-06 | Inline AI |
| P5-10 | XPC Agent lifecycle、任务计划和 capability broker | P0-07, P5-06 | Agent service |
| P5-11 | AI 作业恢复、限流、超时、重试和离线排队 | P3-03, P5-10 | Reliable AI jobs |
| P5-12 | prompt/model/eval 版本与回归 harness | P5-05…11 | AI eval system |

### 测试方法

- Mock server 注入流截断、429、5xx、无效 JSON、错序事件、慢响应和取消。
- Contract suite 以相同任务验证各 adapter capability 与降级。
- 行内 AI 在输入压力、IME、选区变化和快速取消下测主线程延迟。
- Agent 请求越权工具、超调用数、超预算和过期 revision，均应拒绝提交。

### 阶段验收

- 至少一个本地/系统、一个 OpenAI-compatible、三个云 adapter 通过协议测试。
- 模型不可用时核心产品无阻断；任务状态可理解、可恢复。
- AI 写入 100% 可审阅/追溯/撤销；日志不含密钥和未经授权正文。
- 行内建议达到响应/取消预算且不污染撤销栈。

## 9. P6 — Skills 与 MCP

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P6-01 | manifest/包格式/schema/compatibility 定义 | P5-10 | Skill spec v1 |
| P6-02 | staging 解包、hash/signature、原子安装 | P6-01 | Installer |
| P6-03 | 权限模型、grant store 与权限预览 UI | P6-01, P5-02 | Permission center |
| P6-04 | Prompt-only runtime 与工具白名单 | P6-03, P5-10 | Prompt skills |
| P6-05 | WASI runtime、资源限制和虚拟文件系统 | P0-07, P6-03 | Executable skills |
| P6-06 | 网络 broker、域名/方法/大小/超时策略 | P6-03/05 | Network capability |
| P6-07 | 启停、升级、降级、卸载与依赖冲突 | P6-02 | Lifecycle manager |
| P6-08 | 调用审计、诊断与撤销关联 | P6-04…07 | Skill audit |
| P6-09 | MCP client、授权和 tool schema translation | P5-10, P6-03 | MCP client |
| P6-10 | loopback MCP server、短期 token 与关闭开关 | P6-03, P4 query | Local MCP server |
| P6-11 | 三个示例 Skill、SDK 和安全文档 | P6-04…10 | Reference skills |
| P6-12 | 恶意包/注入/越权/崩溃/资源耗尽测试 | 全部 | Security report |

### 测试方法

- 生成路径穿越、符号链接、超大包、篡改签名、依赖环和降级攻击 fixture。
- 尝试未授权读取、写入、联网、环境变量和进程启动。
- XPC/WASI crash、无限循环、内存超限和取消，验证主应用稳定与事务回滚。
- MCP server 尝试非 loopback、过期 token、重放和超大 payload。

### 阶段验收

- 越权成功率 0；未授权外发 0；主应用被 Skill 拖崩 0。
- 安装生命周期可重复且失败时回到上一稳定版本。
- 每次工具调用能定位到 Skill、版本、权限、任务、影响对象和结果。

## 10. P7 — Apple 生态与多设备同步

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P7-01 | CloudKit schema/custom zones/CKRecord mapping | P0-06, P3-01 | Sync schema v1 |
| P7-02 | CKSyncEngine state、pending changes、push/pull | P7-01 | Sync engine |
| P7-03 | Operation 去重、乱序、tombstone 与 asset 分片 | P7-02, P3-02/04 | Reliable replication |
| P7-04 | Block/field merge 与 Conflict Review | P7-03, P2-01 | Conflict resolver |
| P7-05 | 新设备 bootstrap、账户切换和同步诊断 | P7-02…04 | Sync UX |
| P7-06 | Photos 授权、相关候选和原件导入 | P2-08 | Photos integration |
| P7-07 | MapKit 地点、精度控制和地图卡片 | P2-10 | Location integration |
| P7-08 | WeatherKit 快照与 attribution | P7-07 | Weather integration |
| P7-09 | MusicKit 授权、曲目引用和播放候选 | P2-10 | Music integration |
| P7-10 | Share Extension/Services/App Intents/Spotlight | P3-01/05 | System entry points |
| P7-11 | iPhone 快速采集与分享 companion | P7-01/02 | Companion app |
| P7-12 | iPhone HealthKit 摘要选择、转换和同步 | P7-11, P7-03 | Health bridge |
| P7-13 | 双设备 72h 离线/并发/大附件/权限矩阵 | 全部 | Device validation |

### 测试方法

- Fake engine + 真机 CloudKit 两套；注入网络切换、推送丢失、服务器拒绝和配额错误。
- 两设备随机并发 block 操作并最终比较 operation 集与 projection 哈希。
- 针对每个 Apple 权限测试 full/limited/denied/revoked。
- Health fixture 验证只同步摘要，不含原始 sample ID/原始记录。

### 阶段验收

- 72h 离线后最终收敛；重复 push/pull 不重复实体。
- 重叠正文冲突双方保留，用户可合并并撤销。
- 权限拒绝不造成空白卡片、循环弹窗或核心功能退化。
- 新设备可按需恢复全部文字与选定媒体。

## 11. P8 — 回顾、知识体验与图谱设计门

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P8-01 | 首页/今日聚合与轻量回顾策略 | P4, P7 | Home/Today |
| P8-02 | Inbox Review：失败、低置信、冲突、提案 | P4-11, P5-08, P7-04 | Review center |
| P8-03 | 手帐年/月/主题视图与媒体叙事 | P2, P7 | Journal experience |
| P8-04 | 主题/来源/相关内容页面和回链 | P4-09/10 | Knowledge browsing |
| P8-05 | 周期总结、随机回顾、待办提取与频率控制 | P4, P5 | Reflection system |
| P8-06 | AI 助手上下文卡片与结果保存 | P5, P8-04 | Assistant UX |
| P8-07 | 用户接受/拒绝反馈形成 Rule Proposal | P4-12, P8-02 | Rule feedback |
| P8-08 | 知识图谱需求、信息架构与视觉探索 | P4-10 | Graph design brief |
| P8-09 | 图谱高保真原型、动效与可访问性规格 | P8-08 | Graph design contract |
| P8-10 | ForceAtlas2/Barnes–Hut + Metal 技术探针 | P4-10 | Graph benchmark |
| P8-11 | 图谱设计/性能评审门 | P8-09/10 | Go/hold decision |
| P8-12 | 仅在 go 后实现并测试图谱产品 UI | P8-11=go | Knowledge graph |

### 测试方法

- 真实日常数据完成 30 天使用模拟，评估干扰、重复建议和可解释性。
- 手帐长文、密集照片、无元数据和部分授权状态逐屏 snapshot。
- 图谱在 1k/10k/100k 节点验证布局收敛、缩放、选择和后台取消；用户测试比较可读性。

### 阶段验收

- 记录、自动整理、查找、审阅、回顾形成闭环，用户无需维护目录。
- 所有主动提醒可关闭/调频；没有为了展示 AI 而制造操作。
- 图谱只有在独立高保真与性能门通过后启用；否则任务状态为“等待设计”，不是交付缩水。

## 12. P9 — 系统级验证与个人发布

### 任务拆分

| ID | 任务 | 依赖 | 输出 |
|---|---|---|---|
| P9-01 | 建立 FR→SPEC→PLAN→Test traceability 全表 | P0–P8 | Coverage matrix |
| P9-02 | 全量回归、随机长期运行和 soak test | P0–P8 | Stability report |
| P9-03 | 启动/输入/内存/能耗/搜索/同步优化 | P9-02 | Performance report |
| P9-04 | 所有历史 schema/规则/Skill 格式迁移矩阵 | P3–P8 | Migration report |
| P9-05 | 备份、空机恢复、灾难恢复演练 | P3, P7 | Recovery sign-off |
| P9-06 | Threat model 收口、依赖审计、权限与日志扫描 | P0, P5–P7 | Security sign-off |
| P9-07 | VoiceOver、键盘、对比度、减少动态和中英文本地化 | P1–P8 | Accessibility sign-off |
| P9-08 | App Sandbox/Hardened Runtime/signing/notarization | P9-06 | Release app |
| P9-09 | 可复现开源构建、许可证、数据格式和 SDK 文档 | P9-08 | Source release |
| P9-10 | 执行 PRD 八个端到端验收场景 | 全部 | Final acceptance |

### 测试方法

- 用接近真实数据规模做 7 天 soak；注入进程终止、断网、磁盘临界和 provider 故障。
- 在两台干净 Mac 与一台 iPhone 上从安装到恢复完整演练。
- 静态/动态扫描 Keychain、entitlements、网络域名、日志、Skill/MCP 边界和导出包。
- 对发布构建而非 Debug 构建重复性能、snapshot 和 UI 主路径。

### 阶段验收

- PRD、DESIGN、TECHNICAL 的所有 P0/P1 需求与门槛通过；P2 功能已交付或有明确测试证据。
- 高危安全问题、静默数据丢失、不可恢复迁移、主路径崩溃和核心可访问性问题为 0。
- 签名/公证应用在干净机器可安装；源码可按文档复现等价构建。
- `v1.0.0` 备份能在空白环境恢复并通过哈希、引用和全文搜索核对。

## 13. 需求追踪模板

每个阶段执行计划复制并维护以下字段：

| Requirement | Spec Phase | Plan Task | Test Case | Evidence | Status |
|---|---|---|---|---|---|
| `FR-…` | `P…` | `P…-…` | `TC-…` | 日志/截图/报告链接 | Planned/In Progress/Passed/Blocked |

状态只能依据证据更新。若发现需求缺口，先更新 PRD；若改变架构，先写 ADR；若改变视觉，先更新 DESIGN 并重新做对照 QA。

## 14. 阶段启动清单

每个阶段开始前必须确认：

- 上一阶段所有退出门槛已通过或有正式例外记录。
- 本阶段任务被拆成可独立验收的 PR，依赖和 owner 清晰。
- 基准数据、测试设备、供应商账户和 Apple entitlement 已准备。
- 不确定的产品行为已回到 PRD/DESIGN 决策，而不是由开发临场猜测。
- 性能、安全、迁移和可访问性预算已进入具体测试任务。

## 15. 阶段结束清单

- 运行并保存全部阶段测试证据。
- 在发布构建上完成主旅程和视觉回归。
- 完成数据迁移、备份/恢复和故障注入。
- 更新 traceability、ADR、已知限制与用户说明。
- 只在全部退出门槛通过后建立下一阶段基线。

